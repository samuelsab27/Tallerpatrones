package com.balitechy.spacewar.main.interfaces;

import java.awt.*;

public interface PlayerGraphic {
    void render(Graphics g, double x, double y);
}
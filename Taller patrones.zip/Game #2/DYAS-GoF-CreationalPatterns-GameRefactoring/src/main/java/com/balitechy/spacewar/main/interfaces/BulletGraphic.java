package com.balitechy.spacewar.main.interfaces;

import java.awt.*;

public interface BulletGraphic {
    void render(Graphics g, double x, double y);
}

package com.balitechy.spacewar.main.interfaces;

import java.awt.*;

public interface BackgroundGraphic {
    void render(Graphics g, Canvas c);
}
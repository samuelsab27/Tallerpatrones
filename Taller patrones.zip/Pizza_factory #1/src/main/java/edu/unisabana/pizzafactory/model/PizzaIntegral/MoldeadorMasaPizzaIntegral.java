
package edu.unisabana.pizzafactory.model.PizzaIntegral;

import edu.unisabana.pizzafactory.model.interfaces.MoldeadorMasa;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cesarvefe
 */
public class MoldeadorMasaPizzaIntegral implements MoldeadorMasa {


    @Override
    public void moldearMasaPizzaPequena() {
        Logger.getLogger(MoldeadorMasaPizzaIntegral.class.getName())
                .log(Level.INFO, "[O] Moldeando pizza pequena de masa integral.");
        
        //CODIGO DE LLAMADO AL MICROCONTROLADOR

    }

    @Override
    public void moldearMasaPizzaMediana() {
        Logger.getLogger(MoldeadorMasaPizzaIntegral.class.getName())
                .log(Level.INFO, "[O] Moldeando pizza mediana de masa integral.");
        
        //CODIGO DE LLAMADO AL MICROCONTROLADOR
    }

}

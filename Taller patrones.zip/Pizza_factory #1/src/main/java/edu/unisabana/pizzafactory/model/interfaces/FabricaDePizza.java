package edu.unisabana.pizzafactory.model.interfaces;

public interface FabricaDePizza {
    AmasadorMasa crearAmasadorMasa();
    HorneadorPizza crearHorneadorPizza();
    MoldeadorMasa crearMoldeadorMasa();
}

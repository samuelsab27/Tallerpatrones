
package edu.unisabana.pizzafactory.model.PizzaGruesa;
import edu.unisabana.pizzafactory.model.interfaces.HorneadorPizza;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cesarvefe
 */
public class HorneadorPizzaPizzaGruesa implements HorneadorPizza {

    public void hornearPizza() {
        Logger.getLogger(AmasadorMasaPizzaGruesa.class.getName())
            .log(Level.INFO, "[~~] Horneando la pizza con masa gruesa.");

        //CODIGO DE LLAMADO AL MICROCONTROLADOR
    }
    
}


package edu.unisabana.pizzafactory.model.PizzaGruesa;

import edu.unisabana.pizzafactory.model.interfaces.MoldeadorMasa;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cesarvefe
 */
public class MoldeadorMasaPizzaGruesa implements MoldeadorMasa {


    @Override
    public void moldearMasaPizzaPequena() {
        Logger.getLogger(MoldeadorMasaPizzaGruesa.class.getName())
                .log(Level.INFO, "[O] Moldeando pizza pequena de masa gruesa.");
        
        //CODIGO DE LLAMADO AL MICROCONTROLADOR

    }

    @Override
    public void moldearMasaPizzaMediana() {
        Logger.getLogger(MoldeadorMasaPizzaGruesa.class.getName())
                .log(Level.INFO, "[O] Moldeando pizza mediana de masa gruesa.");
        
        //CODIGO DE LLAMADO AL MICROCONTROLADOR
    }

}

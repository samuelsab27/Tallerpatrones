package edu.unisabana.pizzafactory.model.PizzaDelgada;
import edu.unisabana.pizzafactory.model.interfaces.AmasadorMasa;
import edu.unisabana.pizzafactory.model.interfaces.FabricaDePizza;
import edu.unisabana.pizzafactory.model.interfaces.HorneadorPizza;
import edu.unisabana.pizzafactory.model.interfaces.MoldeadorMasa;

public class FabricaDePizzaDelgada implements FabricaDePizza {
    public AmasadorMasa crearAmasadorMasa() {
        return new AmasadorMasaPizzaDelgada();
    }

    public HorneadorPizza crearHorneadorPizza() {
        return new HorneadorPizzaPizzaDelgada();
    }

    public MoldeadorMasa crearMoldeadorMasa() {
        return new MoldeadorMasaPizzaDelgada();
    }
}
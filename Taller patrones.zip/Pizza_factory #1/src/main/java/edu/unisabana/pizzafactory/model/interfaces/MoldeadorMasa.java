package edu.unisabana.pizzafactory.model.interfaces;

public interface MoldeadorMasa {
    void moldearMasaPizzaMediana();
    void moldearMasaPizzaPequena();
}
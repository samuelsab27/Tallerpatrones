package edu.unisabana.pizzafactory.model.interfaces;

public interface AmasadorMasa {
    void amasarMasa();
}
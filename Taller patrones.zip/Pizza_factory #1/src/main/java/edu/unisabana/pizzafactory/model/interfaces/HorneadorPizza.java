package edu.unisabana.pizzafactory.model.interfaces;

public interface HorneadorPizza {
    void hornearPizza();
}

package edu.unisabana.pizzafactory.model.PizzaDelgada;

import edu.unisabana.pizzafactory.model.interfaces.HorneadorPizza;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cesarvefe
 */
public class HorneadorPizzaPizzaDelgada implements HorneadorPizza {

    public void hornearPizza() {
        Logger.getLogger(HorneadorPizzaPizzaDelgada.class.getName())
            .log(Level.INFO, "[~~] Horneando la pizza delgada con masa convencional.");

        //CODIGO DE LLAMADO AL MICROCONTROLADOR
    }
    
}

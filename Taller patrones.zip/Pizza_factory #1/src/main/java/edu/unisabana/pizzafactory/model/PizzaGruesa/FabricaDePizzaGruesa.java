package edu.unisabana.pizzafactory.model.PizzaGruesa;
import edu.unisabana.pizzafactory.model.interfaces.AmasadorMasa;
import edu.unisabana.pizzafactory.model.interfaces.FabricaDePizza;
import edu.unisabana.pizzafactory.model.interfaces.HorneadorPizza;
import edu.unisabana.pizzafactory.model.interfaces.MoldeadorMasa;

public class FabricaDePizzaGruesa implements FabricaDePizza {
    public AmasadorMasa crearAmasadorMasa() {
        return new AmasadorMasaPizzaGruesa();
    }

    public HorneadorPizza crearHorneadorPizza() {
        return new HorneadorPizzaPizzaGruesa();
    }

    public MoldeadorMasa crearMoldeadorMasa() {
        return new MoldeadorMasaPizzaGruesa();
    }
}
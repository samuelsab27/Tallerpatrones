
package edu.unisabana.pizzafactory.consoleview;

import edu.unisabana.pizzafactory.model.PizzaDelgada.AmasadorMasaPizzaDelgada;
import edu.unisabana.pizzafactory.model.ExcepcionParametrosInvalidos;
import edu.unisabana.pizzafactory.model.PizzaDelgada.FabricaDePizzaDelgada;
import edu.unisabana.pizzafactory.model.PizzaDelgada.HorneadorPizzaPizzaDelgada;
import edu.unisabana.pizzafactory.model.IngredientePizza;
import edu.unisabana.pizzafactory.model.PizzaDelgada.MoldeadorMasaPizzaDelgada;
import edu.unisabana.pizzafactory.model.PizzaIntegral.FabricaDePizzaIntegral;
import edu.unisabana.pizzafactory.model.TamanoPizza;
import edu.unisabana.pizzafactory.model.interfaces.AmasadorMasa;
import edu.unisabana.pizzafactory.model.interfaces.FabricaDePizza;
import edu.unisabana.pizzafactory.model.interfaces.HorneadorPizza;
import edu.unisabana.pizzafactory.model.interfaces.MoldeadorMasa;

import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cesarvefe
 */
public class PreparadorDePizza {

    public static void main(String args[]){
        try {
            IngredientePizza[] ingredientes=new IngredientePizza[]{new IngredientePizza("queso",1),new IngredientePizza("jamon",2)};            
            PreparadorDePizza pp=new PreparadorDePizza();
            FabricaDePizza fabrica=new FabricaDePizzaIntegral();
            pp.prepararPizza(fabrica,ingredientes, TamanoPizza.MEDIANO);
        } catch (ExcepcionParametrosInvalidos ex) {
            Logger.getLogger(PreparadorDePizza.class.getName()).log(Level.SEVERE, "Problema en la preparacion de la Pizza", ex);
        }
                
    }
    
    
    public void prepararPizza(FabricaDePizza fabrica, IngredientePizza[] ingredientes, TamanoPizza tam)
            throws ExcepcionParametrosInvalidos {
        AmasadorMasa am = fabrica.crearAmasadorMasa();
        HorneadorPizza hpd = fabrica.crearHorneadorPizza();
        MoldeadorMasa mp = fabrica.crearMoldeadorMasa();

        am.amasarMasa();
        if (tam == TamanoPizza.PEQUENO) {
            mp.moldearMasaPizzaPequena();
        } else if (tam == TamanoPizza.MEDIANO) {
            mp.moldearMasaPizzaMediana();
        } else {
            throw new ExcepcionParametrosInvalidos("TamanoPizza de piza invalido:"+tam);
        }
	aplicarIngredientePizzas(ingredientes);
        hpd.hornearPizza();
    }

    private void aplicarIngredientePizzas(IngredientePizza[] ingredientes) {
        Logger.getLogger(PreparadorDePizza.class.getName())
                .log(Level.INFO, "APLICANDO INGREDIENTES!:{0}", Arrays.toString(ingredientes));
        
        //CODIGO PARA LLAMAR AL MICROCONTROLADOR
        
        
        
    }


}

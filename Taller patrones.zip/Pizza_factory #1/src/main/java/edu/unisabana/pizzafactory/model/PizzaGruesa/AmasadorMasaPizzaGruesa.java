
package edu.unisabana.pizzafactory.model.PizzaGruesa;

import edu.unisabana.pizzafactory.model.interfaces.AmasadorMasa;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cesarvefe
 */
public class AmasadorMasaPizzaGruesa implements AmasadorMasa {

    
    
    public void amasarMasa() {
        Logger.getLogger(AmasadorMasaPizzaGruesa.class.getName())
                .log(Level.INFO, "[@@] Amasando la pizza con masa gruesa.");
        
        //CODIGO DE LLAMADO AL MICROCONTROLADOR
        
    }
    
}

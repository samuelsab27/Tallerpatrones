
package edu.unisabana.pizzafactory.model.PizzaDelgada;

import edu.unisabana.pizzafactory.model.interfaces.AmasadorMasa;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cesarvefe
 */
public class AmasadorMasaPizzaDelgada implements AmasadorMasa {

    
    
    public void amasarMasa() {
        Logger.getLogger(AmasadorMasaPizzaDelgada.class.getName())
                .log(Level.INFO, "[@@] Amasando la pizza delgada con masa convencional.");
        
        //CODIGO DE LLAMADO AL MICROCONTROLADOR
        
    }
    
}

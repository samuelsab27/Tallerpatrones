
package edu.unisabana.pizzafactory.model;

/**
 *
 * @author cesarvefe
 */
public enum TamanoPizza {
    
    MEDIANO, PEQUENO;
    
}

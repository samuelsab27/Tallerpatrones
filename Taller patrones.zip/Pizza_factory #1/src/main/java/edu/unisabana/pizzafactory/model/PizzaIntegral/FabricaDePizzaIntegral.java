package edu.unisabana.pizzafactory.model.PizzaIntegral;

import edu.unisabana.pizzafactory.model.interfaces.AmasadorMasa;
import edu.unisabana.pizzafactory.model.interfaces.FabricaDePizza;
import edu.unisabana.pizzafactory.model.interfaces.HorneadorPizza;
import edu.unisabana.pizzafactory.model.interfaces.MoldeadorMasa;

public class FabricaDePizzaIntegral implements FabricaDePizza {
    public AmasadorMasa crearAmasadorMasa() {
        return new AmasadorMasaPizzaIntegral();
    }

    public HorneadorPizza crearHorneadorPizza() {
        return new HorneadorPizzaPizzaIntegral();
    }

    public MoldeadorMasa crearMoldeadorMasa() {
        return new MoldeadorMasaPizzaIntegral();
    }
}